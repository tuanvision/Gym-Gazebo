^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package wiimote
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.0 (2017-02-10)
-------------------
* Sample Teleop Implementation for Wiimote
* C++ Implementation of Wiimote Controller Node
* Add queue_size to remove ROS Warning
* Update dependencies to remove warnings
* Contributors: Mark D Horn

1.10.1 (2015-05-24)
-------------------

1.10.0 (2014-06-26)
-------------------
* First indigo release
