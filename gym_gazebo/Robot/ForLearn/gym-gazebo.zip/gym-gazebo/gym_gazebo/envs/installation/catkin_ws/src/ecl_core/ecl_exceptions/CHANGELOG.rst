=========
Changelog
=========

0.61.14 (2016-06-16)
--------------------
* expose the string message in the exception api

