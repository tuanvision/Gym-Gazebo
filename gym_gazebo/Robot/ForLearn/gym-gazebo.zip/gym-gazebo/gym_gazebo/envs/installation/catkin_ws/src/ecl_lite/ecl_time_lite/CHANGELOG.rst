^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ecl_time_lite
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.61.1 (2015-07-26)
-------------------
* support get_date_string on macosx.

0.61.0 (2014-09-12)
-------------------
* unique get date string function for unique filename creation.
* optional flag for getting real time instead of monolithic posix time (this syncs with ROS)

0.60.1 (2014-01-29)
-------------------
* update to catkin's CFG_EXTRAS for easy to find cmake modules.
* Contributors: Daniel Stonier
