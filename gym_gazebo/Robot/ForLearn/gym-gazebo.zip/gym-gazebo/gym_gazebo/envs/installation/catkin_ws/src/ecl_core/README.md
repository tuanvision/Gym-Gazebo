ecl_core
========

A set of tools and interfaces extending the capabilities of c++ to provide a lightweight,
consistent interface with a focus for control programming.
