^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ecl_geometry
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.61.15 (2016-11-09)
--------------------
* pose -> legacy pose
* new pose (function only) library started, should eliminate the need for most type conversions

0.61.7 (2016-01-09)
-------------------
* avoid cubic spline calculations when incoming data has only one point

0.61.1 (2015-07-22)
-------------------
* linear segments and shortest path to these

