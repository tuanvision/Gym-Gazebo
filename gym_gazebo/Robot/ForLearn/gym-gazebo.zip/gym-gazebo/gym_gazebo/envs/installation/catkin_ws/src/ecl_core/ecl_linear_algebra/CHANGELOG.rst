=========
Changelog
=========

0.61.8 (2016-01-10)
-------------------
* drop the c++11 transitive export flag, catkin installs dont support this

0.61.7 (2016-01-09)
-------------------
* transitively export c++11 requirement instead of forcing users to do it

0.61.5 (2015-11-24)
-------------------
* expose sophus and add some sophus helpers/utilities.

0.61.0 (2014-09-12)
-------------------
* eigen matrix formatter api aligned with other ecl float formatters
