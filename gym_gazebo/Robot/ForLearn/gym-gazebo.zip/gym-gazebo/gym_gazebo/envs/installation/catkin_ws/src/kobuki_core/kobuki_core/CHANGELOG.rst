^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_core
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.1 (2015-05-27)
------------------

0.6.0 (2014-08-04)
------------------

0.5.3 (2013-09-06)
------------------

0.5.2 (2013-08-31)
------------------
* Fix the list of packages on this stack.

0.5.1 (2013-08-30)
------------------

0.5.0 (2013-08-29)
------------------
* Separated into kobuki_core stack.
* adds eclipse project files.
* adds the kobuki random walker to the kobuki metapackage.
* Added extra url info on all packages.
* Updated old rnd email address.
* Fix URL to the previous changelog wiki.
* Changelogs at package level.


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/kobuki/ChangeList
