^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package driver_common
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.6.8 (2014-03-30)
------------------

1.6.7 (2013-08-21)
------------------
* No more Willow Garage email.
* Contributors: Chad Rockey

1.6.6 (2013-05-06)
------------------
* Updated metapackage for REP 127
* Contributors: chadrockey

1.6.5 (2013-01-22)
------------------

1.6.4 (2012-12-14)
------------------

1.6.3 (2012-12-13)
------------------

1.6.2 (2012-12-10)
------------------
* Version 1.6.2
* Contributors: William Woodall

1.6.1 (2012-12-07 16:02)
------------------------
* added metapackage for former stack
* Contributors: Dirk Thomas

1.6.0 (2012-12-07 11:00)
------------------------
