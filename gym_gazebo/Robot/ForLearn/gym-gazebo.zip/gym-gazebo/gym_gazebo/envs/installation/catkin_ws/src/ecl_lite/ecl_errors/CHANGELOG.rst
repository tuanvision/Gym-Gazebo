^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ecl_errors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.61.1 (2015-07-26)
-------------------
* Add a missing virtual destructor
