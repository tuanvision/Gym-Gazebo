^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package spacenav_node
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.0 (2017-02-10)
-------------------
* Update dependencies to remove warnings
* Contributors: Mark D Horn

1.10.1 (2015-05-24)
-------------------
* Add full_scale parameter and apply to offset
* Remove stray architechture_independent flags
* Contributors: Gaël Ecorchard, Jonathan Bohren, Scott K Logan

1.10.0 (2014-06-26)
-------------------
* First indigo release
