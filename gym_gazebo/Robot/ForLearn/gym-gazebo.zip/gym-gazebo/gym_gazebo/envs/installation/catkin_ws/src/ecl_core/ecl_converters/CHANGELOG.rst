=========
Changelog
=========

0.61.18 (2017-06-26)
--------------------
* disable byte array failed size test in release mode (debug exceptions only)

0.61.4 (2015-10-10)
-------------------
* fix byte array converter error handling in release mode

