=========
Changelog
=========

0.61.15 (2016-11-09)
--------------------
* Class added for computing cumulative means and variances
