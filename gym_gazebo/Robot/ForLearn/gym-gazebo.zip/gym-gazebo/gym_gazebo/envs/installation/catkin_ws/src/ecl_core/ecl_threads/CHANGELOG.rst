^^^^^^^^^
Changelog
^^^^^^^^^

0.61.4 (2015-10-10)
-------------------
* fix long standing bug in mutex tests on the build farm - skip deadlock tests in release mode

0.61.1 (2015-07-22)
-------------------
* don't detach an ecl thread that hasn't been started

0.61.0 (2014-09-12)
-------------------
* const'ness for appropriate thread functions

0.60.6 (2014-01-29)
-------------------
* update to catkin's CFG_EXTRAS for easy to find cmake modules.
* remove cmake debug message.
* Contributors: Daniel Stonier
