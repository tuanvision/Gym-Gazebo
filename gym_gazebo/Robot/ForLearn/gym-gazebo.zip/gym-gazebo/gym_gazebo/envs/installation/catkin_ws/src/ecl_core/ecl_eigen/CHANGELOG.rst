^^^^^^^^^
Changelog
^^^^^^^^^

0.61.16 (2017-01-13)
--------------------
* find Eigen3 instead of Eigen (that is deprecating)

0.61.0 (2014-09-12)
-------------------
* internal eigen support for v3.2.1
* bugfix missing unsupported modules in the install space.

0.60.9 (2014-04-09)
-------------------
* transfer eigen hunting to ros cmake modules

0.60.7 (2014-02-03)
-------------------
* export devel prefix include path to ensure configured headers are found.
* export local header directory.

