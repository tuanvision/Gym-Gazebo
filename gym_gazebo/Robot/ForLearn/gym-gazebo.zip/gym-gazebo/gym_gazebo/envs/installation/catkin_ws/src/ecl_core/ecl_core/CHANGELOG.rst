^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ecl_core
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.60.8 (2014-02-10)
-------------------

0.60.7 (2014-02-03)
-------------------

0.60.6 (2014-01-29)
-------------------

----------------
Older ChangeLogs
----------------

0.60.5 (2013-07-05)
-------------------

* Bugfixes for catkin library finding in raring.

0.60.2 (2013-07-02)
-------------------

* Bugfixes to windows port.

0.60.0 (2013-06-28)
-------------------

* Windows port
* First **hydro** release.

0.50.5 (2013-02-15) 
-------------------

0.50.4 (2013-02-15) 
-------------------

* Bugfixes for catkin.

0.50.3 (2012-12-22) 
-------------------

* Bugfixes for quantal's gcc.
* Parallel build directory header generation.

0.50.2 (2012-12-15) 
-------------------

* Catkin upgrade fixes.

0.50.1 (2012-12-01) 
-------------------

* Bugfixes for ecl in release mode builds.

0.50.0 (2012-10-30) 
-------------------

* Upgraded for catkin.
* First **groovy** release.

0.43.9 (2012-05-24) 
-------------------

* Upgraded with bugfixes for fuerte and precise.
* First **fuerte** release.

0.43.8 (2012-04-17) 
-------------------

* Upgraded eigen and dependant modules.

0.43.6 (2012-01-13) 
-------------------

* Initial stack import into ros.
* First **electric** release.



