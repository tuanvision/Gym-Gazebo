=========
Changelog
=========

0.61.6 (2016-06-16)
-------------------

* accomodate platforms (e.g. macosx) without SOCK_NONBLOCK
