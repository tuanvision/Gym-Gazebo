roslint
=======

[![Build Status](http://jenkins.ros.org/buildStatus/icon?job=devel-indigo-roslint/ARCH_PARAM=amd64,UBUNTU_PARAM=trusty,label=devel)](http://jenkins.ros.org/job/devel-indigo-roslint/ARCH_PARAM=amd64,UBUNTU_PARAM=trusty,label=devel/)

Catkin macros which provide standard linter configurations for C++ and Python.
