=========
Changelog
=========

0.61.9 (2016-02-23)
-------------------
* improved output of the quatnerion-yaw utilities

0.61.1 (2015-07-22)
-------------------
* quaternion2yaw utility

0.61.0 (2014-09-12)
-------------------
* yaw2quaternion converter.

