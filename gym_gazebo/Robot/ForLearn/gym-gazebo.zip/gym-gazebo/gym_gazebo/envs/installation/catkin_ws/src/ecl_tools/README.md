ecl_tools
=========

Build environment tools and utilities for the embedded control libraries.

The development branch now uses ament. The most recent catkin based branches are on [release/0.61-indigo-kinetic](https://github.com/stonier/ecl_tools/tree/release/0.61-indigo-kinetic) and [release/0.61-lunar](https://github.com/stonier/ecl_tools/tree/release/0.61-lunar).
