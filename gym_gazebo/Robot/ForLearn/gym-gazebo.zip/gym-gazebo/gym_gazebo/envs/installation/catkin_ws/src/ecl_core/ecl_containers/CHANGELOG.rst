^^^^^^^^^
Changelog
^^^^^^^^^

0.61.18 (2017-06-26)
--------------------
* bugfix trivial gcc7.1 error

0.61.2 (2015-08-12)
-------------------
* byte array converters for long long

0.61.0 (2014-09-12)
-------------------
* stencil for unsigned char* arrays.
* byte array converters for vector based stencils. 
