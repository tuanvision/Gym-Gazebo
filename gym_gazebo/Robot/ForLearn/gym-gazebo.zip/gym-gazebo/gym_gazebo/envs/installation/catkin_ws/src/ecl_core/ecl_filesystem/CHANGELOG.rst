^^^^^^^^^
Changelog
^^^^^^^^^

0.61.17 (2017-02-05)
--------------------
* bugfix implicit 'rt' dependency in catkin_package (removed)

0.61.3 (2015-09-05)
-------------------
* fix build dirs for devel build.

0.61.0 (2014-09-12)
-------------------
* const'ness for appropriate thread functions

0.60.6 (2014-01-29)
-------------------
* update to catkin's CFG_EXTRAS for easy to find cmake modules.
* remove cmake debug message.
* Contributors: Daniel Stonier
