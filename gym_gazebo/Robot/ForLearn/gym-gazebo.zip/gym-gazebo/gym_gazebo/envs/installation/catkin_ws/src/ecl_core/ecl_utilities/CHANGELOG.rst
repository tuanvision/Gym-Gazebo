^^^^^^^^^
Changelog
^^^^^^^^^

0.61.0 (2014-09-12)
-------------------
* partially bound binary function members.

