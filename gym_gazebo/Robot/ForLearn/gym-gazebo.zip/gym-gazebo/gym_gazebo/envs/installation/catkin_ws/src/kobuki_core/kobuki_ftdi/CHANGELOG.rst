^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_ftdi
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.1 (2015-05-27)
------------------
* remove kobuki_ros kobuki_nodelet libaries export in catkin_package closes `#16 <https://github.com/yujinrobot/kobuki_core/issues/16>`_
* Contributors: Jihoon Lee

0.6.0 (2014-08-04)
------------------
* Fix compilation.
  - fix the names of the pkg-config libraries of libusb and libftdi. I checked on Ubuntu and OS X.
  - ftdi-eeprom is not a library and has no pkg-config file.
* Update the readme in kobuki_ftdi
* Create README.md
* kobuki_ftdi : Updated doxygen document.
* Contributors: Jihoon Lee, Nikolaus Demmel, Younghun Ju

0.5.3 (2013-09-06)
------------------

0.5.2 (2013-08-31)
------------------

0.5.1 (2013-08-30)
------------------
* Updated license info.

0.5.0 (2013-08-29)
------------------
* Added extra url info on all packages.
* Updated old rnd email address.
* Fix URL to the previous changelog wiki.
* Changelogs at package level.

0.4.0 (2013-08-09)
------------------


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/kobuki/ChangeList
