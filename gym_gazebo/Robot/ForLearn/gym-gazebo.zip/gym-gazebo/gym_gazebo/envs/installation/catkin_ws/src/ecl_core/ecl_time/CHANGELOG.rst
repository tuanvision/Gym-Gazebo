=========
Changelog
=========

0.61.17 (2017-02-05)
--------------------
* bugfix realtime_now() to not return temporaries

0.61.12 (2016-05-03)
--------------------
* consideration for time on apple for the frequency class

0.61.6 (2015-11-25)
-------------------
* bugfix frequency monitor timestamp initialisation

0.61.5 (2015-11-24)
-------------------
* frequency monitor

0.61.1 (2015-07-22)
-------------------
* negative support for timestamps

0.61.0 (2014-09-12)
-------------------
* random number generator
* optional realtime stamping (not monotone) to sync with ros stamps

