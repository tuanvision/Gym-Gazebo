^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ecl_ipc
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.61.12 (2016-05-03)
--------------------
* minor bugfix for includes on apple osx

0.60.8 (2014-02-10)
-------------------
* ecl_ipc requires ecl_build for cmake modules.
* make sure we detect threads in this module
* Contributors: Daniel Stonier

0.60.7 (2014-02-03)
-------------------

0.60.6 (2014-01-29)
-------------------
