^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ecl_concepts
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.61.13 (2016-05-03)
--------------------
* drop unused typedefs 
